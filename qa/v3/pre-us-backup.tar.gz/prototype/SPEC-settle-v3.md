# Settle-up v3 parity spec (Figma file z4TesJNPe6UfvgwmWtIA4y, 18 Oct 2026)

These numbers come from `ledger.ts`: pairwise() and then simplify() run on baseExpenses plus tonight's dinner (Ari paid €248.70, with Ren and Nic taken off the wine). If the ledger changes, Figma has to change with it.

## Debt Simplification v4 "Instrument" (Figma set 121:4174, card 362×268)
I built two directions on the board "Explore · Tangled graph directions" next to the component in Design System. A (Instrument) uses graphite threads, a dot grid, crossing knots and a mono panel. B (Flow) tints every IOU Iris and adds particles. I chose A because Iris stays reserved for the answer: in Solved the three payment arcs are the only purple lines on the card, so the eye lands on them. B made the mess look like the answer.

All coordinates are inside the 362×268 card (radius 20, bg/surface, shadow/card). Graph centre CX 181, CY 112.

### Nodes
| key | name | centre | net |
|---|---|---|---|
| A | You (Ari) | 181,58 | −23.70 |
| S | Sofia | 278,80 | 0.00 |
| N | Nic | 306,126 | +42.10 |
| M | Mara | 236,166 | −64.00 |
| T | Tomás | 126,166 | 0.00 |
| J | João | 56,126 | +64.00 |
| R | Ren | 84,80 | −18.40 |

- Chip: 32px circle, bg/surface-raised, 1px border/subtle, shadow rgba(20,18,51,0.10) y1 blur3. Monogram SF Pro Semibold 12, text/primary. Ari's chip is filled accent/primary with text/on-accent.
- Ring: 40px track around the chip, arc inner radius 0.93, border/subtle.
- Balance arc (Netting and Solved only): inner radius 0.90, sweep = |net| / 64.00 × 360°. Positive nets sweep clockwise from 12 o'clock in status/owed. Negative nets sweep counter-clockwise in status/owe. Zero nets show the track only.
- In Solved, zero-net nodes (Sofia, Tomás) drop to 38% opacity and their labels to 45%.

### Labels
- Frame with horizontal auto layout, gap 4, padding 1/4, radius 4, bg/surface at 88%. Name in mono/tag (JetBrains Mono 10), text/tertiary in Tangled and text/secondary after. Netting and Solved add the signed net in mono/tag, coloured status/owed, status/owe or text/tertiary.
- Placement: centred above the node when its y < CY − 20, otherwise centred below, 3px off the 40px ring.
- Ari: right of the chip at x + 25, vertically centred. In Netting and Solved the label stacks name over net (vertical, gap 0) so it stays clear of Sofia's.
- Sofia in Netting and Solved: x is clamped to at least 256 and at most 354 − width.

### Technical layer (all states)
- Dot grid: 12px pitch, x 13 to 349, y 34 to 194, 1.25px dots, radial gradient border/strong at the centre to border/subtle at 60% to transparent.
- Orbit: dashed ellipse 250×108 centred on CX, CY, border/strong 0.75px, dash 1.5 / 3.5.
- Side ticks every 12px, every 4th one longer, text/tertiary at 45%.
- Crosshair at the centre in Solved only.
- Stepper at 16,11 in mono/micro (10/12, +0.4 tracking): `01 TANGLED`, `02 NETTING`, `03 SOLVED`, joined by 12px hairlines. The active step is accent/text with a filled dot. The others are text/tertiary with a hollow dot.

### Edge geometry
- Each edge is a quadratic bezier. Control = midpoint + (centre − midpoint) × bend. It starts 24px from the source centre and ends 23px from the target centre.
- Bend search: try |bend| from 0.46 down to 0.06 in the preferred sign, keep the first value that clears every other node by at least 27px, then try the opposite sign. Preferred bends: Ari→Tomás 0.12, Ren→Ari 0.25, Mara→João 0.15, Mara→Sofia 0.10, Sofia→João 0.10, Tomás→Nic 0.28. In Solved: Ari→Nic 0.30, Ren→Ari 0.30, Mara→João 0.35.
- Tags: pill, width = characters × 6 + 10, height 14, radius 7, mono/tag. They are placed by searching t from 0.22 to 0.78 and perpendicular offsets 0, ±6, ±11, ±14, scoring overlap with nodes, labels, other tags, other curves and the card bounds. No tag may overlap anything.

### Tangled
- 6 threads. Weight = 1 + 1.5 × min(amount, 42.10) / 42.10, so 42.10 is 2.5px and 18.40 is 1.66px.
- Stroke gradient along the flow: border/strong at 0, text/tertiary at 0.22, text/secondary at 1. Round caps.
- Arrowhead: filled triangle in text/secondary, base 7px behind the tip, half-width max(3, 1.35 × weight). The curve is shortened by 5.5px so it doesn't poke through.
- Crossings are computed from 48-segment polylines, ignoring points within 26px of a node. That gives 4. Each one gets a 12px glow (accent/primary at 10%, layer blur 4) under a 5px knot (bg/surface fill, 1px accent/primary at 60%).
- Tags: bg/surface at 96%, 1px border/strong, text/secondary.
- Panel: `IOUS 6 · 7 people` | `CROSSINGS 4` | `FLOW €190.60`.

### Netting
- Threads go dashed 2/3, 1px, text/tertiary at 35%, with no arrowheads or tags.
- Endpoint dots, 5px: status/owe where money leaves, status/owed where it lands.
- Centre pill `Σ 0.00` in mono/tag.
- Balance arcs appear on every ring.
- Panel: `Σ NET 0.00 ✓` | `OWED +106.10` | `OWE −106.10`.

### Solved
- 3 arcs: Ari→Nic 42.10, Ren→Ari 18.40, Mara→João 64.00. Weight 3px when the amount is ≥ 40, otherwise 2.25px. None cross.
- Gradient along the flow: accent/subtle at 0, accent/primary at 0.35, accent/primary at 1. Arrowheads in accent/primary.
- Tags: bg/surface, 1px accent/subtle, accent/text, `€42.10` style.
- Panel: `PAYMENTS 3 was 6` | `FLOW €124.50` | `SAVED 50% 3 fewer`.

### Instrument panel
- At 16,206, 330×50, radius 12, bg/sunken at 55%, 1px border/subtle inside. Three equal cells with 1px border/subtle dividers. Each cell has a caption in mono/micro text/tertiary over a value in mono/value (JetBrains Mono Medium 13/16) text/primary. Status values use status colours.

### Motion
| step | duration | easing | what moves |
|---|---|---|---|
| Tangled in | 400ms | cubic-bezier(0.2,0,0,1) | Threads draw from source to target (stroke-dashoffset), staggered 40ms. Knots scale from 0.6 to 1 after their threads land. |
| Tangled → Netting | 600ms | cubic-bezier(0.2,0,0,1) | Threads fade to 35% and switch to dashed over the first 200ms. Arrowheads, tags and knots fade out. Balance arcs sweep from 0 to their angle over 600ms. Nets count up from 0.00 in tabular figures. The Σ pill fades in at 400ms. |
| Netting → Solved | 600ms | cubic-bezier(0.2,0,0,1) | Dashed threads fade out over 200ms. The 3 payment arcs draw on, staggered 80ms, then arrowheads and tags fade in. Zero-net nodes dim to 38%. Panel values cross-fade. |
| Haptics | | | `.light` impact when each payment arc lands, `.success` notification when Solved settles. |

Reduce Motion: no path drawing and no count-up. Each state cross-fades at 200ms linear. Rings show at their final sweep. Haptics stay.

## Screens
- 09a Tangled (201:9341). Caption: "2 IOUs: you owe Tomás €42.10. Ren owes you €18.40." Log card `IOUS · 6 · €190.60 MOVED` lists the 6 IOUs; rows that involve Ari use text/primary. Button: "Simplify 6 IOUs".
- 09b Netting (201:9484). Caption: "Every IOU becomes one net balance per person." Log `NET = PAID − SHARE · Σ 0.00`. The button "Finding the fewest payments" is disabled.
- 09 Balances (137:6808, dark 137:6901): Solved state. Row reasons: "Tejo boat tour, via Tomás" · "Dinner share minus Fado tickets" · "Flat deposit, via Sofia". CTA "Pay Nic €42.10".

## All squared up (104:3446, overlay 121:4318)
- Glass sheet: bg/surface at 90%, background blur 24, shadow/float, scrim bg/scrim with blur 12.
- One spectrum glow (angular gradient, 132px, layer blur 26, 85%) sits behind a 64px surface disc that holds a drawn check. That glow is the only colour moment. No confetti, no 3D render, no gradient text, no rainbow stripes.
- Mono eyebrow `22:41 · LISBON CREW · SETTLED`. Serif title "All squared up." in text/primary. Body "3 payments, €124.50 in total. Everyone in Lisbon Crew is at €0.00."
- Mono receipt (bg/sunken 80%): `Ari → Nic €42.10 22:39` / `Ren → Ari €18.40 22:40` / `Mara → João €64.00 cash ✓` / `total €124.50 3 of 3`. Primary button: "Share the recap".
- Reduce Motion: the glow is static and the sheet fades in.

## Settle-up flow, cash path end to end (Figma section 09, y 7800 light, y 8800 dark)
Ten frames at 402×874, built from the 09 Balances chrome: Status Bar, glass Nav Bar (back label, serif title, subtitle), Content column at x 20, y 214, width 362, and the Home indicator. Dark frames are clones with the Semantic collection set to Dark and card/float/accent shadows swapped for their -dark styles. Edge E02 (143:6885) now uses S2.

| # | frame (light / dark) | nav back · title · subtitle | export |
|---|---|---|---|
| S1 | 226:6928 / 227:7211 | Money · Pay Nic · Payment 1 of 3 · simplified | settle-01-choose-method |
| S2 | 226:7018 / 227:7301 | Pay Nic · Cash for Nic · Count it out, then slide | settle-02-cash-count-round |
| S3 | 226:7100 / 227:7383 | same as S2, slider held at 78% | settle-03-cash-slide |
| S4 | 226:7183 / 227:7466 | Money · Cash for Nic · Waiting for Nic | settle-04-cash-pending-undo |
| S5 | 226:7245 / 227:7528 | Lisbon Crew · Did Ari pay you? · Nic's phone · cash · 22:39 | settle-05-nic-confirm |
| S6 | 226:7310 / 227:7593 | Lisbon Crew · Money · Whole trip · 7 people | settle-06-confirmed-1-of-3 |
| S7 | 226:7385 / 227:7668 | Money · Receipt · You → Nic · cash | settle-07-receipt |
| E1 | 226:7489 / 227:7772 | Pay Nic · Cash for Nic · Paying part now | settle-08-edge-partial-cash |
| E2 | 226:7563 / 227:7846 | Money · Pay Nic · Cash · needs a look | settle-09-edge-dispute |
| E3 | 226:7637 / 227:7920 | Money · Pay Nic · Cash · offline | settle-10-edge-offline |

### Shared parts
- Card: bg/surface, radius 20, padding 16, gap 12, shadow/card. Tone variants: rose uses status/owe-subtle fill with a status/owe 1px stroke.
- Pill: radius 999, padding 2/8, mono/tag. Tones: owed (status/owed-subtle on status/owed), owe, accent (accent/subtle on accent/text), neutral (bg/sunken on text/secondary).
- Pair hero: two 32px chips joined by a 56px Iris gradient arrow, amount in display/l (44), caption in ui/subhead text/secondary, pill top right.
- Mono readout: bg/sunken at 70%, radius 14, padding 12/14, gap 4. Header row in mono/micro text/tertiary with an optional pill. Rows are label left in mono/readout text/secondary, value right in mono/readout text/primary, tabular figures. Carried amounts use accent/text, gaps use status/owe.
- Overline: mono/micro, uppercase, text/tertiary.
- Primary CTA: Button Primary L, x 20, y 788, width 362. When a second button stacks, the primary sits at y 724.
- Every frame keeps a 16px gap between the last content block and the CTA or slider. Checked with an overlap audit on all 20 frames.

### S1 Choose how
- Hero: Ari → Nic, €42.10, caption "For the Tejo boat tour, routed through Tomás.", pill `1 OF 3`, link "Why €42.10" (opens S7's provenance block).
- Overline "HOW YOU'LL PAY", then a list card with 5 rows (36px tile, title ui/callout, meta ui/footnote, 22px radio on the right):
  - TripUp Pay · Visa •• 4821 · arrives now
  - MB WAY · +351 912 ••• 214 · opens MB WAY
  - Revolut · @nicmendes · opens Revolut
  - Bank transfer · PT50 •••• 0457 · 1 business day
  - Cash · Hand it over in person (selected in this flow)
- CTA label follows the selection: "Pay €42.10 with TripUp Pay", "Open MB WAY", "Open Revolut", "Copy bank details", "Continue with cash".
- MB WAY and Revolut hand off by deep link with the amount and reference `STL_7Q2K-0042` prefilled. On return, the app shows S4 with the copy "Did it go through?" and buttons "Yes, I sent it" and "Not yet", because those apps don't confirm back to us.

### S2 Count and round
- Hero card: overline HAND OVER, €42.00 in display/xl (56), pills `rounded from €42.10` (neutral) and `€0.10 carried` (accent).
- Round toggle card: "Round to €42.00" / "The €0.10 moves to the next split, so nobody counts coins tonight." Toggle on by default for cash.
- Count it out: note pills `€20 × 2`, `€2 × 1` and `= €42.00`. Notes come from a greedy split over 50, 20, 10, 5, 2, 1, 0.50, 0.20, 0.10.
- Readout `CASH · YOU → NIC`: due 42.10 / hand over 42.00 / carry → next split 0.10.
- Row "Paying part of it?" opens E1.
- Slider "Slide to mark €42.00 paid".

### Rounding rules
- Cash only. Round to the nearest €1.00, so the change is never more than €0.50 either way. €42.10 becomes €42.00.
- The difference becomes a carry entry on the same pair (Ari ↔ Nic). It joins the next simplify() run. If the trip closes with a carry under €0.50 left, it is written off and shown as "rounded" in the recap.
- With the toggle off, hand over is the exact amount and the count includes coins.

### Slide to settle (S2, S3)
- Track 362×64, radius 32, bg/surface, 1px border/strong, shadow/card. Knob 56px accent/primary with shadow/accent, 4px inset, arrow icon 24 in text/on-accent.
- Progress fill from the left edge to knob + 60, linear gradient accent/subtle to accent/primary at 55%.
- Haptic ticks: 2×10 marks at 25%, 50%, 75% of travel. Each fires `.selection` haptic once per crossing and turns text/on-accent at 80% when passed.
- Past 50% the label fades and "Release to confirm" shows in text/on-accent. Past 92% the knob icon becomes a check and a `.medium` impact fires once.
- Release past 92%: the knob snaps to the end in 180ms ease-out, `.success` notification, go to S4. Release earlier: spring back to 0 (stiffness 400, damping 30), no haptic.
- Content above dims to 55% while the knob is held (S3).
- Reduce Motion or VoiceOver: the track becomes a button "Mark €42.00 paid" that needs a 600ms long press with a circular fill, or a VoiceOver double tap followed by a confirm alert.

### S4 Pending and undo
- 72px check disc (accent/subtle with a 1.5px accent/primary stroke), "Marked as paid", body "Nic gets a request to confirm €42.00 in cash. Your balance moves when he does."
- Readout TIMELINE with pill `PENDING`: `22:39:04 you marked cash €42.00 ✓`, `22:39:04 request sent to Nic ✓`, `--:--:-- Nic confirms pending`. Summary chip `due 42.10 · paid 42.00 · carried 0.10`.
- Undo toast at y 716: text/primary fill, 20px countdown ring, "Marked €42.00 paid · 4s", action "Undo". The window is 5s. Undo deletes the mark and withdraws Nic's request. After 5s the toast slides away and undo moves into the receipt as "Cancel the cash mark" until Nic confirms.
- Ghost button "Back to balances".
- Your balance doesn't change while pending. The 09 row for You → Nic shows a `PENDING` pill.

### S5 Nic confirms (receiver)
- Push to Nic: "Ari marked €42.00 cash for you. Tap to confirm." Opens S5.
- Hero €42.00, caption "Ari marked this as cash, handed over in person.", pill `NEEDS YOU`.
- Readout `RECEIPT · STL_7Q2K-0042`: due 42.10 / Ari gave 42.00 / carried → next split 0.10 / for "Tejo boat tour, via Tomás".
- Note: "Your balance updates when you confirm. If the count is off, tap Not yet and say what you got."
- Buttons "Yes, I got €42.00" (Primary, y 724) and "Not yet" (Secondary, y 788). Not yet opens a sheet with an amount field and a note, which leads to E2 on Ari's phone.
- If Nic does nothing for 24h, Ari gets "Nic hasn't confirmed €42.00 yet" with Remind and Cancel.

### S6 Confirmed, 1 of 3
- YOUR BALANCE +€18.30 in status/owed, "Ren pays you €18.40. €0.10 carried to your next split."
- Success card: 40px owed check disc, "Nic confirmed €42.00", meta `cash · 22:40:12 · stl_7Q2K-0042`.
- Progress: overline `1 OF 3 SETTLED`, right `€42.00 of €124.50`, a 3-segment bar (filled segments accent/primary, others bg/sunken, 4px tall, 4px gaps).
- Rows: You → Nic with pill `€42.00 ✓`, Ren → You €18.40 (status/owed), Mara → João €64.00.
- CTA "Ask Ren for €18.40".
- Micro-moment on arrival: the check disc scales 0.8 → 1 over 320ms with spring (stiffness 300, damping 20), `.success` haptic, the first bar segment fills in 400ms. Reduce Motion: 200ms fade, no scale.

### S7 Receipt and provenance
- Hero €42.00 with pill `CONFIRMED`, caption "Tejo boat tour, routed through Tomás".
- Readout PAYMENT: id stl_7Q2K-0042 · from Ari (you) · to Nic · method cash · in person · due €42.10 · paid €42.00 · carried €0.10 → next split · marked 22:39:04 · Ari · confirmed 22:40:12 · Nic · sync both phones ✓.
- Readout WHERE IT CAME FROM: LX Factory lunch · Tomás paid +79.80 / Dinner · you paid −37.70 / you owe Tomás 42.10 / Tomás owes Nic · boat tour 42.10 / simplified: you → Nic 42.10.
- Secondary "Share receipt" exports a PNG of the two readouts.

### E1 Partial cash
- Hero: overline HAND OVER NOW, €20.00, "of €42.10 due". Quick pills €10, €20 (selected, accent), €40, All €42.10. Custom amount by tapping the hero.
- Bar: filled 20.00 / 42.10, labels `now 20.00` and `left 22.10`.
- Readout PARTIAL · YOU → NIC: due 42.10 / hand over now 20.00 / stays open on the plan 22.10.
- Note: "The other €22.10 stays on your plan. Pay it in cash or in the app later."
- Slider "Slide to mark €20.00 paid". Rounding is off for partial payments, and the remainder keeps the original reference with suffix `-b`.

### E2 Dispute
- Rose card: "Nic counted €40.00", pill `DISPUTED`, "Nic tapped Not yet at 22:41: “Got two twenties, no coin.”"
- Readout COUNT CHECK: you marked 42.00 / Nic counted 40.00 / gap 2.00 (status/owe).
- WHAT NOW (radio list): Hand over the €2 coin (Nic confirms €42.00, same as before) · Change it to €40.00 (€2.10 stays on your plan) · Cancel the cash mark (back to €42.10 open).
- CTA "Send to Nic". Balances stay as they were until both phones agree.

### E3 Offline
- Card: "No connection", "Saved on this phone. It goes to Nic as soon as you're back online."
- Hero €42.00 with pill `QUEUED`, "Marked 22:39, not sent yet."
- Readout SYNC: queue 1 payment / last sync 22:31:48 / retry on reconnect, then every 30 s / balances pending until Nic confirms.
- Ghost "Cancel the cash mark". The mark is stored with a client id so a retry can't double-post.

### States and data
```ts
type SettleMethod = 'tripup' | 'mbway' | 'revolut' | 'bank' | 'cash';
type SettleStatus = 'draft' | 'queued' | 'pending' | 'confirmed' | 'disputed' | 'cancelled';
interface Settlement {
  id: string;            // 'stl_7Q2K-0042'
  clientId: string;      // idempotency key for offline retries
  from: PersonId; to: PersonId;
  due: number;           // 42.10, from simplify()
  paid: number;          // 42.00
  carry: number;         // due - paid when rounded, 0.10
  method: SettleMethod;
  status: SettleStatus;
  markedAt?: string; confirmedAt?: string;
  dispute?: { counted: number; note: string; at: string };
  provenance: { label: string; amount: number }[];
}
```
- draft → (slide) → pending, or queued when offline. queued → pending on reconnect.
- pending → confirmed when the receiver taps yes. pending → disputed when they tap Not yet. Either side can cancel while pending.
- disputed → pending after the payer picks a fix and sends it. disputed → cancelled.
- Balances and the 1 of 3 counter only change on confirmed. App payments (TripUp Pay) go straight to confirmed when the processor returns success.
- Money is stored in cents as integers. Display uses tabular figures and the € prefix, with the minus sign U+2212.

### Recap variant with cash
The All squared up recap (hi-fi 10) shows the app path: €124.50 across 3 payments. When cash rounding happens, the receipt row reads `Ari → Nic €42.00 cash ✓` and the body reads "3 payments, €124.40 handed over, €0.10 carried to your next split."

### Reduce Motion for the flow
- Screen transitions become 200ms cross-fades.
- The slider becomes the long-press button described above.
- The undo countdown ring is replaced by a static "5s" number that updates each second.
- The success check and bar fill appear without scaling or sweeping. Haptics stay.
